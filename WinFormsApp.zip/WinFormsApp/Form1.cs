﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          var encrypt=  Utils.Encrypt(textBox1.Text);
            label2.Text = encrypt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var decrypt= Utils.Decrypt(textBox2.Text);
            label1.Text=decrypt;
            
            string configvalue2 = ConfigurationManager.AppSettings["logfilelocation"];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using(LoginForm frmLogin=new LoginForm())
            {
               if(frmLogin.ShowDialog() == DialogResult.OK)
                {
                    var pass = frmLogin.UserPassword;
                    string password = Utils.Decrypt(ConfigurationManager.AppSettings["config"]); 
                    if(password == pass)
                    {
                        //habilitar boton edicion guardado
                        MessageBox.Show("pass valida!", "Atencion", MessageBoxButtons.OK);
                    }
                    else
                    {
                        MessageBox.Show("invalid pass!", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    // hacer otra cosa
                }
            }
        }
    }
}
